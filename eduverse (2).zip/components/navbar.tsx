"use client"

import { useState } from "react"
import Link from "next/link"
import styles from "@/styles/navbar.module.css"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className={styles.navbar}>
      <div className={styles.container}>
        <div className={styles.navbarContent}>
          <Link href="/" className={styles.logo}>
            <span className={styles.logoIcon}>E</span>
            <span className={styles.logoText}>EduVerse</span>
          </Link>

          {/* Desktop Navigation */}
          <div className={styles.desktopNav}>
            <div className={styles.navLinks}>
              <NavLink href="/courses">Courses</NavLink>
              <NavLink href="/tutors">Tutors</NavLink>
              <NavLink href="/about">About</NavLink>
              <NavLink href="/contact">Contact</NavLink>
            </div>

            <div className={styles.authButtons}>
              <Link href="/login" className={styles.loginButton}>
                Log In
              </Link>
              <Link href="/signup" className={styles.signupButton}>
                Sign Up
              </Link>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button className={styles.menuButton} onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className={styles.mobileNav}>
            <div className={styles.mobileNavLinks}>
              <MobileNavLink href="/courses" onClick={() => setIsMenuOpen(false)}>
                Courses
              </MobileNavLink>
              <MobileNavLink href="/tutors" onClick={() => setIsMenuOpen(false)}>
                Tutors
              </MobileNavLink>
              <MobileNavLink href="/about" onClick={() => setIsMenuOpen(false)}>
                About
              </MobileNavLink>
              <MobileNavLink href="/contact" onClick={() => setIsMenuOpen(false)}>
                Contact
              </MobileNavLink>
            </div>

            <div className={styles.mobileAuthButtons}>
              <Link href="/login" className={styles.mobileLoginButton} onClick={() => setIsMenuOpen(false)}>
                Log In
              </Link>
              <Link href="/signup" className={styles.mobileSignupButton} onClick={() => setIsMenuOpen(false)}>
                Sign Up
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

function NavLink({ href, children }) {
  return (
    <Link href={href} className={styles.navLink}>
      {children}
    </Link>
  )
}

function MobileNavLink({ href, onClick, children }) {
  return (
    <Link href={href} className={styles.mobileNavLink} onClick={onClick}>
      {children}
    </Link>
  )
}

function MenuIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="3" y1="12" x2="21" y2="12"></line>
      <line x1="3" y1="6" x2="21" y2="6"></line>
      <line x1="3" y1="18" x2="21" y2="18"></line>
    </svg>
  )
}

function CloseIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  )
}
