"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import styles from "@/styles/dashboard-layout.module.css"

export default function DashboardLayout({ children }) {
  const pathname = usePathname()
  const isTutor = pathname.includes("/dashboard/tutor")
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const [notifications] = useState([
    { id: 1, message: "New message from Dr. Sarah Johnson", time: "2 minutes ago" },
    { id: 2, message: "Your course progress has been updated", time: "1 hour ago" },
    { id: 3, message: "New course recommendation available", time: "3 hours ago" },
  ])

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen)
  }

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  return (
    <div className={styles.dashboard}>
      {/* Sidebar */}
      <aside className={`${styles.sidebar} ${isSidebarOpen ? styles.open : styles.closed}`}>
        <div className={styles.sidebarHeader}>
          <Link href="/" className={styles.logo}>
            <span className={styles.logoIcon}>E</span>
            <span className={styles.logoText}>EduVerse</span>
          </Link>
          <button className={styles.sidebarToggle} onClick={toggleSidebar}>
            {isSidebarOpen ? <ChevronLeftIcon /> : <ChevronRightIcon />}
          </button>
        </div>
        <nav className={styles.sidebarNav}>
          <ul className={styles.navList}>
            <li>
              <NavLink
                href={`/dashboard/${isTutor ? "tutor" : "student"}`}
                isActive={pathname === `/dashboard/${isTutor ? "tutor" : "student"}`}
                icon={<HomeIcon />}
                label="Dashboard"
                isSidebarOpen={isSidebarOpen}
              />
            </li>

            {isTutor ? (
              <>
                <li>
                  <NavLink
                    href="/dashboard/tutor/courses"
                    isActive={pathname.includes("/courses") && !pathname.includes("/create-course")}
                    icon={<BookIcon />}
                    label="My Courses"
                    isSidebarOpen={isSidebarOpen}
                  />
                </li>
                <li>
                  <NavLink
                    href="/dashboard/tutor/create-course"
                    isActive={pathname.includes("/create-course")}
                    icon={<PlusIcon />}
                    label="Create Course"
                    isSidebarOpen={isSidebarOpen}
                  />
                </li>
                <li>
                  <NavLink
                    href="/dashboard/tutor/upload-video"
                    isActive={pathname.includes("/upload-video")}
                    icon={<VideoIcon />}
                    label="Upload Video"
                    isSidebarOpen={isSidebarOpen}
                  />
                </li>
                <li>
                  <NavLink
                    href="/dashboard/tutor/students"
                    isActive={pathname.includes("/students")}
                    icon={<UsersIcon />}
                    label="Students"
                    isSidebarOpen={isSidebarOpen}
                  />
                </li>
              </>
            ) : (
              <>
                <li>
                  <NavLink
                    href="/dashboard/student/courses"
                    isActive={pathname.includes("/courses")}
                    icon={<BookIcon />}
                    label="My Courses"
                    isSidebarOpen={isSidebarOpen}
                  />
                </li>
                <li>
                  <NavLink
                    href="/dashboard/student/discover"
                    isActive={pathname.includes("/discover")}
                    icon={<SearchIcon />}
                    label="Discover"
                    isSidebarOpen={isSidebarOpen}
                  />
                </li>
              </>
            )}

            <li>
              <NavLink
                href={`/dashboard/${isTutor ? "tutor" : "student"}/messages`}
                isActive={pathname.includes("/messages")}
                icon={<MessageIcon />}
                label="Messages"
                isSidebarOpen={isSidebarOpen}
              />
            </li>

            <li>
              <NavLink
                href={`/dashboard/${isTutor ? "tutor" : "student"}/settings`}
                isActive={pathname.includes("/settings")}
                icon={<SettingsIcon />}
                label="Settings"
                isSidebarOpen={isSidebarOpen}
              />
            </li>
          </ul>
        </nav>
        <div className={styles.sidebarFooter}>
          <div className={styles.userInfo}>
            <div className={styles.userAvatar}>{isTutor ? "PC" : "SN"}</div>
            {isSidebarOpen && (
              <div className={styles.userData}>
                <div className={styles.userName}>{isTutor ? "Professor Chad" : "Student Name"}</div>
                <div className={styles.userRole}>{isTutor ? "Tutor" : "Student"}</div>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={styles.main}>
        {/* Header */}
        <header className={styles.header}>
          <div className={styles.headerLeft}>
            <button className={styles.mobileMenuButton} onClick={toggleMobileMenu}>
              <MenuIcon />
            </button>
          </div>
          <div className={styles.headerRight}>
            <div className={styles.notificationDropdown}>
              <button className={styles.notificationButton}>
                <BellIcon />
                <span className={styles.notificationBadge}>{notifications.length}</span>
              </button>
              <div className={styles.dropdownContent}>
                <div className={styles.dropdownHeader}>Notifications</div>
                <div className={styles.notificationList}>
                  {notifications.map((notification) => (
                    <div key={notification.id} className={styles.notificationItem}>
                      <div className={styles.notificationMessage}>{notification.message}</div>
                      <div className={styles.notificationTime}>{notification.time}</div>
                    </div>
                  ))}
                </div>
                <div className={styles.dropdownFooter}>
                  <Link href="#" className={styles.viewAllLink}>
                    View all notifications
                  </Link>
                </div>
              </div>
            </div>
            <div className={styles.userDropdown}>
              <button className={styles.userButton}>
                <div className={styles.userAvatar}>{isTutor ? "PC" : "SN"}</div>
              </button>
              <div className={styles.dropdownContent}>
                <div className={styles.dropdownHeader}>
                  <div className={styles.userName}>{isTutor ? "Professor Chad" : "Student Name"}</div>
                  <div className={styles.userEmail}>user@example.com</div>
                </div>
                <div className={styles.dropdownLinks}>
                  <Link href="/profile" className={styles.dropdownLink}>
                    <UserIcon />
                    <span>Profile</span>
                  </Link>
                  <Link href="/settings" className={styles.dropdownLink}>
                    <SettingsIcon />
                    <span>Settings</span>
                  </Link>
                </div>
                <div className={styles.dropdownFooter}>
                  <Link href="/logout" className={styles.logoutButton}>
                    <LogOutIcon />
                    <span>Log out</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className={styles.mobileMenu}>
            <div className={styles.mobileMenuHeader}>
              <Link href="/" className={styles.logo}>
                <span className={styles.logoIcon}>E</span>
                <span className={styles.logoText}>EduVerse</span>
              </Link>
              <button className={styles.mobileMenuClose} onClick={toggleMobileMenu}>
                <XIcon />
              </button>
            </div>
            <nav className={styles.mobileNav}>
              <ul className={styles.mobileNavList}>
                <li>
                  <Link
                    href={`/dashboard/${isTutor ? "tutor" : "student"}`}
                    className={`${styles.mobileNavLink} ${
                      pathname === `/dashboard/${isTutor ? "tutor" : "student"}` ? styles.active : ""
                    }`}
                    onClick={toggleMobileMenu}
                  >
                    <HomeIcon />
                    <span>Dashboard</span>
                  </Link>
                </li>

                {isTutor ? (
                  <>
                    <li>
                      <Link
                        href="/dashboard/tutor/courses"
                        className={`${styles.mobileNavLink} ${
                          pathname.includes("/courses") && !pathname.includes("/create-course") ? styles.active : ""
                        }`}
                        onClick={toggleMobileMenu}
                      >
                        <BookIcon />
                        <span>My Courses</span>
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/dashboard/tutor/create-course"
                        className={`${styles.mobileNavLink} ${
                          pathname.includes("/create-course") ? styles.active : ""
                        }`}
                        onClick={toggleMobileMenu}
                      >
                        <PlusIcon />
                        <span>Create Course</span>
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/dashboard/tutor/upload-video"
                        className={`${styles.mobileNavLink} ${pathname.includes("/upload-video") ? styles.active : ""}`}
                        onClick={toggleMobileMenu}
                      >
                        <VideoIcon />
                        <span>Upload Video</span>
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/dashboard/tutor/students"
                        className={`${styles.mobileNavLink} ${pathname.includes("/students") ? styles.active : ""}`}
                        onClick={toggleMobileMenu}
                      >
                        <UsersIcon />
                        <span>Students</span>
                      </Link>
                    </li>
                  </>
                ) : (
                  <>
                    <li>
                      <Link
                        href="/dashboard/student/courses"
                        className={`${styles.mobileNavLink} ${pathname.includes("/courses") ? styles.active : ""}`}
                        onClick={toggleMobileMenu}
                      >
                        <BookIcon />
                        <span>My Courses</span>
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/dashboard/student/discover"
                        className={`${styles.mobileNavLink} ${pathname.includes("/discover") ? styles.active : ""}`}
                        onClick={toggleMobileMenu}
                      >
                        <SearchIcon />
                        <span>Discover</span>
                      </Link>
                    </li>
                  </>
                )}

                <li>
                  <Link
                    href={`/dashboard/${isTutor ? "tutor" : "student"}/messages`}
                    className={`${styles.mobileNavLink} ${pathname.includes("/messages") ? styles.active : ""}`}
                    onClick={toggleMobileMenu}
                  >
                    <MessageIcon />
                    <span>Messages</span>
                  </Link>
                </li>

                <li>
                  <Link
                    href={`/dashboard/${isTutor ? "tutor" : "student"}/settings`}
                    className={`${styles.mobileNavLink} ${pathname.includes("/settings") ? styles.active : ""}`}
                    onClick={toggleMobileMenu}
                  >
                    <SettingsIcon />
                    <span>Settings</span>
                  </Link>
                </li>
              </ul>
            </nav>
            <div className={styles.mobileMenuFooter}>
              <Link href="/logout" className={styles.mobileLogoutButton}>
                <LogOutIcon />
                <span>Log out</span>
              </Link>
            </div>
          </div>
        )}

        {/* Content */}
        <div className={styles.content}>{children}</div>
      </main>
    </div>
  )
}

function NavLink({ href, isActive, icon, label, isSidebarOpen }) {
  return (
    <Link href={href} className={`${styles.navLink} ${isActive ? styles.active : ""}`}>
      <span className={styles.navIcon}>{icon}</span>
      {isSidebarOpen && <span className={styles.navLabel}>{label}</span>}
    </Link>
  )
}

// Icons
function HomeIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
      <polyline points="9 22 9 12 15 12 15 22"></polyline>
    </svg>
  )
}

function BookIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2 3h6a4 4 0 0 1 4 4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
    </svg>
  )
}

function PlusIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="12" y1="5" x2="12" y2="19"></line>
      <line x1="5" y1="12" x2="19" y2="12"></line>
    </svg>
  )
}

function VideoIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polygon points="23 7 16 12 23 17 23 7"></polygon>
      <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
    </svg>
  )
}

function UsersIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
      <circle cx="9" cy="7" r="4"></circle>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
      <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
    </svg>
  )
}

function MessageIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
    </svg>
  )
}

function SettingsIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="3"></circle>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
    </svg>
  )
}

function SearchIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8"></circle>
      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
    </svg>
  )
}

function BellIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
      <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
    </svg>
  )
}

function UserIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
      <circle cx="12" cy="7" r="4"></circle>
    </svg>
  )
}

function LogOutIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
      <polyline points="16 17 21 12 16 7"></polyline>
      <line x1="21" y1="12" x2="9" y2="12"></line>
    </svg>
  )
}

function MenuIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="3" y1="12" x2="21" y2="12"></line>
      <line x1="3" y1="6" x2="21" y2="6"></line>
      <line x1="3" y1="18" x2="21" y2="18"></line>
    </svg>
  )
}

function XIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  )
}

function ChevronLeftIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="15 18 9 12 15 6"></polyline>
    </svg>
  )
}

function ChevronRightIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="9 18 15 12 9 6"></polyline>
    </svg>
  )
}
