"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, MessageCircle, Plus, Users, Video } from "lucide-react"
import DashboardLayout from "@/components/dashboard-layout"

export default function TutorDashboard() {
  const [courses] = useState([
    {
      id: 1,
      title: "Introduction to Computer Science",
      description: "A beginner-friendly course covering the fundamentals of computer science.",
      students: 128,
      videos: 24,
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      title: "Advanced Data Structures",
      description: "Deep dive into complex data structures and algorithms.",
      students: 64,
      videos: 18,
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 3,
      title: "Web Development Fundamentals",
      description: "Learn the basics of HTML, CSS, and JavaScript.",
      students: 256,
      videos: 32,
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
  ])

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Tutor Dashboard</h1>
        <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
          <Plus className="mr-2 h-4 w-4" /> Create Course
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Students"
          value="448"
          description="+12% from last month"
          icon={<Users className="h-4 w-4 text-blue-600 dark:text-blue-400" />}
        />
        <StatsCard
          title="Total Courses"
          value="3"
          description="Active courses"
          icon={<BookOpen className="h-4 w-4 text-blue-600 dark:text-blue-400" />}
        />
        <StatsCard
          title="Total Videos"
          value="74"
          description="Across all courses"
          icon={<Video className="h-4 w-4 text-blue-600 dark:text-blue-400" />}
        />
        <StatsCard
          title="Messages"
          value="24"
          description="Unread messages"
          icon={<MessageCircle className="h-4 w-4 text-blue-600 dark:text-blue-400" />}
        />
      </div>

      <Tabs defaultValue="courses" className="mt-6">
        <TabsList>
          <TabsTrigger value="courses">My Courses</TabsTrigger>
          <TabsTrigger value="students">Students</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
        </TabsList>
        <TabsContent value="courses" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {courses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
            <CreateCourseCard />
          </div>
        </TabsContent>
        <TabsContent value="students">
          <div className="rounded-lg border shadow-sm">
            <div className="p-6">
              <h3 className="text-lg font-medium">Student Enrollments</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                View and manage your students across all courses.
              </p>
            </div>
            <div className="border-t">
              <div className="grid grid-cols-3 gap-4 p-4 font-medium">
                <div>Student</div>
                <div>Course</div>
                <div>Enrollment Date</div>
              </div>
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="grid grid-cols-3 gap-4 border-t p-4">
                  <div>Student {i + 1}</div>
                  <div>{courses[i % courses.length].title}</div>
                  <div>{new Date().toLocaleDateString()}</div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
        <TabsContent value="messages">
          <div className="rounded-lg border shadow-sm">
            <div className="p-6">
              <h3 className="text-lg font-medium">Recent Messages</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                View and respond to messages from your students.
              </p>
            </div>
            <div className="border-t">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="border-t p-4">
                  <div className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-slate-200 dark:bg-slate-700"></div>
                    <div>
                      <div className="font-medium">Student {i + 1}</div>
                      <div className="text-sm text-slate-500 dark:text-slate-400">
                        {courses[i % courses.length].title}
                      </div>
                      <div className="mt-1">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut
                        labore.
                      </div>
                      <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                        {new Date().toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  )
}

function StatsCard({ title, value, description, icon }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-slate-500 dark:text-slate-400">{description}</p>
      </CardContent>
    </Card>
  )
}

function CourseCard({ course }) {
  return (
    <Card className="overflow-hidden">
      <img src={course.thumbnail || "/placeholder.svg"} alt={course.title} className="h-40 w-full object-cover" />
      <CardHeader>
        <CardTitle>{course.title}</CardTitle>
        <CardDescription>{course.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center">
            <Users className="mr-1 h-4 w-4 text-slate-500 dark:text-slate-400" />
            <span>{course.students} students</span>
          </div>
          <div className="flex items-center">
            <Video className="mr-1 h-4 w-4 text-slate-500 dark:text-slate-400" />
            <span>{course.videos} videos</span>
          </div>
        </div>
      </CardContent>
      <div className="flex border-t p-4">
        <Button asChild variant="ghost" size="sm" className="mr-2">
          <Link href={`/dashboard/tutor/courses/${course.id}`}>Manage</Link>
        </Button>
        <Button asChild variant="ghost" size="sm" className="mr-2">
          <Link href={`/dashboard/tutor/courses/${course.id}/videos`}>Videos</Link>
        </Button>
        <Button asChild variant="ghost" size="sm">
          <Link href={`/dashboard/tutor/courses/${course.id}/chat`}>Chat</Link>
        </Button>
      </div>
    </Card>
  )
}

function CreateCourseCard() {
  return (
    <Card className="flex h-full flex-col items-center justify-center p-6">
      <div className="mb-4 rounded-full bg-blue-100 p-3 dark:bg-blue-900/30">
        <Plus className="h-6 w-6 text-blue-600 dark:text-blue-400" />
      </div>
      <h3 className="mb-2 text-lg font-medium">Create New Course</h3>
      <p className="mb-4 text-center text-sm text-slate-500 dark:text-slate-400">
        Start building your next course and share your knowledge
      </p>
      <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
        <Plus className="mr-2 h-4 w-4" /> Create Course
      </Button>
    </Card>
  )
}
