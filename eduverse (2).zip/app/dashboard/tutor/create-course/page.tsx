"use client"

import { useState } from "react"
import Link from "next/link"
import styles from "@/styles/create-course.module.css"
import DashboardLayout from "@/components/dashboard-layout"

export default function CreateCoursePage() {
  const [activeStep, setActiveStep] = useState(1)
  const [courseTitle, setCourseTitle] = useState("")
  const [courseDescription, setCourseDescription] = useState("")
  const [courseCategory, setCourseCategory] = useState("")
  const [courseLevel, setCourseLevel] = useState("")
  const [coursePrice, setCoursePrice] = useState("")
  const [courseThumbnail, setCourseThumbnail] = useState(null)
  const [previewUrl, setPreviewUrl] = useState("")

  // Categories for dropdown
  const categories = [
    "Computer Science",
    "Web Development",
    "Data Science",
    "Mobile Development",
    "Database",
    "Machine Learning",
    "Artificial Intelligence",
    "Cybersecurity",
    "Game Development",
    "Cloud Computing",
  ]

  // Levels for dropdown
  const levels = ["Beginner", "Intermediate", "Advanced", "All Levels"]

  const handleThumbnailChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setCourseThumbnail(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleNextStep = () => {
    setActiveStep((prev) => prev + 1)
  }

  const handlePrevStep = () => {
    setActiveStep((prev) => prev - 1)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // In a real app, you would submit the form data to the server
    console.log({
      courseTitle,
      courseDescription,
      courseCategory,
      courseLevel,
      coursePrice,
      courseThumbnail,
    })
    // Redirect to the course management page
    // window.location.href = "/dashboard/tutor/courses"
  }

  return (
    <DashboardLayout>
      <div className={styles.header}>
        <h1 className={styles.title}>Create New Course</h1>
        <p className={styles.subtitle}>Fill in the details to create your new course</p>
      </div>

      <div className={styles.stepsContainer}>
        <div className={styles.steps}>
          <div className={`${styles.step} ${activeStep >= 1 ? styles.active : ""}`}>
            <div className={styles.stepNumber}>1</div>
            <div className={styles.stepLabel}>Basic Info</div>
          </div>
          <div className={styles.stepConnector}></div>
          <div className={`${styles.step} ${activeStep >= 2 ? styles.active : ""}`}>
            <div className={styles.stepNumber}>2</div>
            <div className={styles.stepLabel}>Course Content</div>
          </div>
          <div className={styles.stepConnector}></div>
          <div className={`${styles.step} ${activeStep >= 3 ? styles.active : ""}`}>
            <div className={styles.stepNumber}>3</div>
            <div className={styles.stepLabel}>Pricing</div>
          </div>
        </div>
      </div>

      <div className={styles.formContainer}>
        {activeStep === 1 && (
          <div className={styles.formStep}>
            <h2 className={styles.formTitle}>Basic Information</h2>
            <p className={styles.formDescription}>
              Provide the basic details about your course. This information will be displayed on the course listing
              page.
            </p>

            <form className={styles.form}>
              <div className={styles.formGroup}>
                <label htmlFor="courseTitle" className={styles.label}>
                  Course Title <span className={styles.required}>*</span>
                </label>
                <input
                  type="text"
                  id="courseTitle"
                  className={styles.input}
                  placeholder="e.g., Introduction to JavaScript"
                  value={courseTitle}
                  onChange={(e) => setCourseTitle(e.target.value)}
                  required
                />
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="courseDescription" className={styles.label}>
                  Course Description <span className={styles.required}>*</span>
                </label>
                <textarea
                  id="courseDescription"
                  className={styles.textarea}
                  placeholder="Provide a detailed description of your course"
                  value={courseDescription}
                  onChange={(e) => setCourseDescription(e.target.value)}
                  rows={5}
                  required
                ></textarea>
              </div>

              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="courseCategory" className={styles.label}>
                    Category <span className={styles.required}>*</span>
                  </label>
                  <select
                    id="courseCategory"
                    className={styles.select}
                    value={courseCategory}
                    onChange={(e) => setCourseCategory(e.target.value)}
                    required
                  >
                    <option value="" disabled>
                      Select a category
                    </option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="courseLevel" className={styles.label}>
                    Level <span className={styles.required}>*</span>
                  </label>
                  <select
                    id="courseLevel"
                    className={styles.select}
                    value={courseLevel}
                    onChange={(e) => setCourseLevel(e.target.value)}
                    required
                  >
                    <option value="" disabled>
                      Select a level
                    </option>
                    {levels.map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="courseThumbnail" className={styles.label}>
                  Course Thumbnail <span className={styles.required}>*</span>
                </label>
                <div className={styles.thumbnailUpload}>
                  {previewUrl ? (
                    <div className={styles.thumbnailPreview}>
                      <img src={previewUrl || "/placeholder.svg"} alt="Course thumbnail preview" />
                      <button
                        type="button"
                        className={styles.thumbnailRemove}
                        onClick={() => {
                          setCourseThumbnail(null)
                          setPreviewUrl("")
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div className={styles.thumbnailDropzone}>
                      <input
                        type="file"
                        id="courseThumbnail"
                        className={styles.fileInput}
                        accept="image/*"
                        onChange={handleThumbnailChange}
                      />
                      <div className={styles.thumbnailPlaceholder}>
                        <UploadIcon />
                        <p>Drag and drop your thumbnail here or click to browse</p>
                        <p className={styles.thumbnailHint}>Recommended size: 1280x720 pixels (16:9 ratio)</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className={styles.formActions}>
                <Link href="/dashboard/tutor" className={styles.cancelButton}>
                  Cancel
                </Link>
                <button type="button" className={styles.nextButton} onClick={handleNextStep}>
                  Next: Course Content
                </button>
              </div>
            </form>
          </div>
        )}

        {activeStep === 2 && (
          <div className={styles.formStep}>
            <h2 className={styles.formTitle}>Course Content</h2>
            <p className={styles.formDescription}>
              Add videos, lectures, and other content to your course. You can add more content later.
            </p>

            <div className={styles.contentSection}>
              <div className={styles.contentHeader}>
                <h3 className={styles.contentTitle}>Course Sections</h3>
                <button type="button" className={styles.addSectionButton}>
                  Add Section
                </button>
              </div>

              <div className={styles.sectionList}>
                <div className={styles.section}>
                  <div className={styles.sectionHeader}>
                    <h4 className={styles.sectionTitle}>Section 1: Introduction</h4>
                    <div className={styles.sectionActions}>
                      <button type="button" className={styles.editButton}>
                        Edit
                      </button>
                      <button type="button" className={styles.deleteButton}>
                        Delete
                      </button>
                    </div>
                  </div>
                  <div className={styles.lectureList}>
                    <div className={styles.lecture}>
                      <div className={styles.lectureInfo}>
                        <VideoIcon />
                        <span className={styles.lectureName}>Welcome to the Course</span>
                        <span className={styles.lectureDuration}>5:30</span>
                      </div>
                      <div className={styles.lectureActions}>
                        <button type="button" className={styles.editButton}>
                          Edit
                        </button>
                        <button type="button" className={styles.deleteButton}>
                          Delete
                        </button>
                      </div>
                    </div>
                    <div className={styles.lecture}>
                      <div className={styles.lectureInfo}>
                        <VideoIcon />
                        <span className={styles.lectureName}>Course Overview</span>
                        <span className={styles.lectureDuration}>10:15</span>
                      </div>
                      <div className={styles.lectureActions}>
                        <button type="button" className={styles.editButton}>
                          Edit
                        </button>
                        <button type="button" className={styles.deleteButton}>
                          Delete
                        </button>
                      </div>
                    </div>
                    <button type="button" className={styles.addLectureButton}>
                      <PlusIcon /> Add Lecture
                    </button>
                  </div>
                </div>

                <div className={styles.section}>
                  <div className={styles.sectionHeader}>
                    <h4 className={styles.sectionTitle}>Section 2: Getting Started</h4>
                    <div className={styles.sectionActions}>
                      <button type="button" className={styles.editButton}>
                        Edit
                      </button>
                      <button type="button" className={styles.deleteButton}>
                        Delete
                      </button>
                    </div>
                  </div>
                  <div className={styles.lectureList}>
                    <button type="button" className={styles.addLectureButton}>
                      <PlusIcon /> Add Lecture
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className={styles.formActions}>
              <button type="button" className={styles.backButton} onClick={handlePrevStep}>
                Back: Basic Info
              </button>
              <button type="button" className={styles.nextButton} onClick={handleNextStep}>
                Next: Pricing
              </button>
            </div>
          </div>
        )}

        {activeStep === 3 && (
          <div className={styles.formStep}>
            <h2 className={styles.formTitle}>Course Pricing</h2>
            <p className={styles.formDescription}>
              Set the price for your course. You can also offer discounts or make your course free.
            </p>

            <form className={styles.form} onSubmit={handleSubmit}>
              <div className={styles.pricingOptions}>
                <div className={styles.pricingOption}>
                  <input type="radio" id="paid" name="pricingType" value="paid" defaultChecked />
                  <label htmlFor="paid">Paid Course</label>
                </div>
                <div className={styles.pricingOption}>
                  <input type="radio" id="free" name="pricingType" value="free" />
                  <label htmlFor="free">Free Course</label>
                </div>
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="coursePrice" className={styles.label}>
                  Course Price ($) <span className={styles.required}>*</span>
                </label>
                <input
                  type="number"
                  id="coursePrice"
                  className={styles.input}
                  placeholder="e.g., 49.99"
                  min="0"
                  step="0.01"
                  value={coursePrice}
                  onChange={(e) => setCoursePrice(e.target.value)}
                  required
                />
              </div>

              <div className={styles.formGroup}>
                <div className={styles.checkboxGroup}>
                  <input type="checkbox" id="discount" className={styles.checkbox} />
                  <label htmlFor="discount" className={styles.checkboxLabel}>
                    Offer a discount
                  </label>
                </div>
              </div>

              <div className={styles.coursePreview}>
                <h3 className={styles.previewTitle}>Course Preview</h3>
                <div className={styles.previewCard}>
                  <div className={styles.previewImage}>
                    {previewUrl ? (
                      <img src={previewUrl || "/placeholder.svg"} alt="Course thumbnail" />
                    ) : (
                      <div className={styles.previewImagePlaceholder}>No thumbnail</div>
                    )}
                  </div>
                  <div className={styles.previewContent}>
                    <h4 className={styles.previewCourseTitle}>{courseTitle || "Course Title"}</h4>
                    <p className={styles.previewCourseDescription}>
                      {courseDescription || "Course description will appear here"}
                    </p>
                    <div className={styles.previewMeta}>
                      <span className={styles.previewCategory}>{courseCategory || "Category"}</span>
                      <span className={styles.previewLevel}>{courseLevel || "Level"}</span>
                    </div>
                    <div className={styles.previewPrice}>${coursePrice || "0.00"}</div>
                  </div>
                </div>
              </div>

              <div className={styles.formActions}>
                <button type="button" className={styles.backButton} onClick={handlePrevStep}>
                  Back: Course Content
                </button>
                <button type="submit" className={styles.submitButton}>
                  Create Course
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}

function UploadIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="17 8 12 3 7 8"></polyline>
      <line x1="12" y1="3" x2="12" y2="15"></line>
    </svg>
  )
}

function VideoIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polygon points="23 7 16 12 23 17 23 7"></polygon>
      <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
    </svg>
  )
}

function PlusIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="12" y1="5" x2="12" y2="19"></line>
      <line x1="5" y1="12" x2="19" y2="12"></line>
    </svg>
  )
}
