"use client"

import { useState, useRef } from "react"
import Link from "next/link"
import styles from "@/styles/upload-video.module.css"
import DashboardLayout from "@/components/dashboard-layout"

export default function UploadVideoPage() {
  const [videoFile, setVideoFile] = useState(null)
  const [videoTitle, setVideoTitle] = useState("")
  const [videoDescription, setVideoDescription] = useState("")
  const [courseId, setCourseId] = useState("")
  const [section, setSection] = useState("")
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [previewUrl, setPreviewUrl] = useState("")
  const videoRef = useRef(null)

  // Mock courses data
  const courses = [
    { id: "1", title: "Introduction to Computer Science" },
    { id: "2", title: "Advanced Data Structures" },
    { id: "3", title: "Web Development Fundamentals" },
  ]

  // Mock sections data based on selected course
  const sections = [
    { id: "1", title: "Introduction" },
    { id: "2", title: "Getting Started" },
    { id: "3", title: "Core Concepts" },
  ]

  const handleVideoChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setVideoFile(file)
      const url = URL.createObjectURL(file)
      setPreviewUrl(url)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    if (!videoFile) {
      alert("Please select a video file")
      return
    }

    // Simulate upload process
    setIsUploading(true)

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          // In a real app, you would redirect to the video details page
          // or show a success message
          return 100
        }
        return prev + 5
      })
    }, 300)
  }

  return (
    <DashboardLayout>
      <div className={styles.header}>
        <h1 className={styles.title}>Upload New Video</h1>
        <p className={styles.subtitle}>Add a new video to your course. The video will be automatically transcribed.</p>
      </div>

      <div className={styles.content}>
        <div className={styles.uploadContainer}>
          {!videoFile ? (
            <div className={styles.uploadArea}>
              <input
                type="file"
                id="videoUpload"
                className={styles.fileInput}
                accept="video/*"
                onChange={handleVideoChange}
              />
              <div className={styles.uploadPlaceholder}>
                <UploadIcon />
                <h3 className={styles.uploadTitle}>Drag and drop your video file here</h3>
                <p className={styles.uploadText}>or click to browse</p>
                <p className={styles.uploadHint}>MP4, MOV, or AVI up to 2GB</p>
              </div>
            </div>
          ) : (
            <div className={styles.videoPreview}>
              <video
                ref={videoRef}
                src={previewUrl}
                controls
                className={styles.videoPlayer}
                onLoadedMetadata={() => {
                  // You can access video duration and other metadata here
                  console.log("Video duration:", videoRef.current.duration)
                }}
              ></video>
              <div className={styles.videoActions}>
                <button
                  type="button"
                  className={styles.changeButton}
                  onClick={() => {
                    setVideoFile(null)
                    setPreviewUrl("")
                  }}
                >
                  Change Video
                </button>
              </div>
            </div>
          )}
        </div>

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label htmlFor="videoTitle" className={styles.label}>
              Video Title <span className={styles.required}>*</span>
            </label>
            <input
              type="text"
              id="videoTitle"
              className={styles.input}
              placeholder="e.g., Introduction to the Course"
              value={videoTitle}
              onChange={(e) => setVideoTitle(e.target.value)}
              required
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="videoDescription" className={styles.label}>
              Description
            </label>
            <textarea
              id="videoDescription"
              className={styles.textarea}
              placeholder="Provide a description of your video"
              value={videoDescription}
              onChange={(e) => setVideoDescription(e.target.value)}
              rows={4}
            ></textarea>
          </div>

          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <label htmlFor="courseId" className={styles.label}>
                Course <span className={styles.required}>*</span>
              </label>
              <select
                id="courseId"
                className={styles.select}
                value={courseId}
                onChange={(e) => setCourseId(e.target.value)}
                required
              >
                <option value="" disabled>
                  Select a course
                </option>
                {courses.map((course) => (
                  <option key={course.id} value={course.id}>
                    {course.title}
                  </option>
                ))}
              </select>
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="section" className={styles.label}>
                Section <span className={styles.required}>*</span>
              </label>
              <select
                id="section"
                className={styles.select}
                value={section}
                onChange={(e) => setSection(e.target.value)}
                required
              >
                <option value="" disabled>
                  Select a section
                </option>
                {sections.map((section) => (
                  <option key={section.id} value={section.id}>
                    {section.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className={styles.formGroup}>
            <div className={styles.checkboxGroup}>
              <input type="checkbox" id="generateTranscript" className={styles.checkbox} defaultChecked />
              <label htmlFor="generateTranscript" className={styles.checkboxLabel}>
                Automatically generate transcript using AI
              </label>
            </div>
          </div>

          {isUploading && (
            <div className={styles.uploadProgress}>
              <div className={styles.progressLabel}>Uploading video... {uploadProgress}%</div>
              <div className={styles.progressBar}>
                <div className={styles.progressFill} style={{ width: `${uploadProgress}%` }}></div>
              </div>
            </div>
          )}

          <div className={styles.formActions}>
            <Link href="/dashboard/tutor/courses" className={styles.cancelButton}>
              Cancel
            </Link>
            <button type="submit" className={styles.submitButton} disabled={!videoFile || isUploading}>
              {isUploading ? "Uploading..." : "Upload Video"}
            </button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  )
}

function UploadIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="48"
      height="48"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="17 8 12 3 7 8"></polyline>
      <line x1="12" y1="3" x2="12" y2="15"></line>
    </svg>
  )
}
