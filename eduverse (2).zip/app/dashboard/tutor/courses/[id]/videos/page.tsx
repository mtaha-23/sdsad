"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronLeft, Plus, Upload, Video } from "lucide-react"
import DashboardLayout from "@/components/dashboard-layout"

export default function CourseVideosPage({ params }) {
  const courseId = params.id

  // Mock course data
  const [course] = useState({
    id: courseId,
    title: "Introduction to Computer Science",
    videos: [
      {
        id: 1,
        title: "Introduction to the Course",
        duration: "10:15",
        status: "published",
        transcript: true,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 2,
        title: "What is Computer Science?",
        duration: "15:30",
        status: "published",
        transcript: true,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 3,
        title: "Algorithms Basics",
        duration: "20:45",
        status: "published",
        transcript: true,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 4,
        title: "Data Structures Overview",
        duration: "18:20",
        status: "processing",
        transcript: false,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 5,
        title: "Introduction to Programming",
        duration: "25:10",
        status: "draft",
        transcript: false,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
    ],
  })

  return (
    <DashboardLayout>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <Link
            href={`/dashboard/tutor/courses/${courseId}`}
            className="mb-2 inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition-colors hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
          >
            <ChevronLeft size={16} />
            Back to Course
          </Link>
          <h1 className="text-3xl font-bold tracking-tight">{course.title}</h1>
          <p className="text-slate-500 dark:text-slate-400">Manage your course videos</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
          <Plus className="mr-2 h-4 w-4" /> Add Video
        </Button>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Videos ({course.videos.length})</TabsTrigger>
          <TabsTrigger value="published">
            Published ({course.videos.filter((v) => v.status === "published").length})
          </TabsTrigger>
          <TabsTrigger value="processing">
            Processing ({course.videos.filter((v) => v.status === "processing").length})
          </TabsTrigger>
          <TabsTrigger value="draft">Draft ({course.videos.filter((v) => v.status === "draft").length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid gap-6">
            {course.videos.map((video) => (
              <VideoCard key={video.id} video={video} courseId={courseId} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="published" className="mt-6">
          <div className="grid gap-6">
            {course.videos
              .filter((video) => video.status === "published")
              .map((video) => (
                <VideoCard key={video.id} video={video} courseId={courseId} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="processing" className="mt-6">
          <div className="grid gap-6">
            {course.videos
              .filter((video) => video.status === "processing")
              .map((video) => (
                <VideoCard key={video.id} video={video} courseId={courseId} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="draft" className="mt-6">
          <div className="grid gap-6">
            {course.videos
              .filter((video) => video.status === "draft")
              .map((video) => (
                <VideoCard key={video.id} video={video} courseId={courseId} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Upload New Video</CardTitle>
          <CardDescription>
            Upload a new video to your course. The video will be automatically transcribed.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <div className="grid gap-3">
              <Label htmlFor="title">Video Title</Label>
              <Input id="title" placeholder="Enter video title" />
            </div>
            <div className="grid gap-3">
              <Label htmlFor="description">Description</Label>
              <Input id="description" placeholder="Enter video description" />
            </div>
            <div className="grid gap-3">
              <Label>Video File</Label>
              <div className="flex h-32 cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed border-slate-300 bg-slate-50 px-6 py-10 text-center dark:border-slate-700 dark:bg-slate-800/50">
                <div className="flex flex-col items-center gap-2">
                  <Upload className="h-6 w-6 text-slate-500 dark:text-slate-400" />
                  <div className="text-sm font-medium">Drag and drop your video file here or click to browse</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">MP4, MOV, or AVI up to 2GB</div>
                </div>
              </div>
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
              Upload Video
            </Button>
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}

function VideoCard({ video, courseId }) {
  return (
    <Card>
      <div className="flex flex-col gap-4 p-4 sm:flex-row">
        <div className="relative h-32 w-full sm:w-56">
          <img
            src={video.thumbnail || "/placeholder.svg"}
            alt={video.title}
            className="h-full w-full rounded-md object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="rounded-full bg-black/50 p-2">
              <Video className="h-4 w-4 fill-white text-white" />
            </div>
          </div>
          {video.status !== "published" && (
            <div className="absolute right-2 top-2 rounded-full bg-white px-2 py-1 text-xs font-medium capitalize dark:bg-slate-800">
              {video.status}
            </div>
          )}
        </div>
        <div className="flex flex-1 flex-col justify-between">
          <div>
            <h3 className="text-lg font-medium">{video.title}</h3>
            <div className="mt-1 flex flex-wrap items-center gap-3">
              <div className="text-sm text-slate-500 dark:text-slate-400">Duration: {video.duration}</div>
              {video.transcript && (
                <div className="flex items-center gap-1 rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                  <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  AI Transcript
                </div>
              )}
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href={`/dashboard/tutor/courses/${courseId}/videos/${video.id}`}>Edit</Link>
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link href={`/dashboard/tutor/courses/${courseId}/videos/${video.id}/transcript`}>
                {video.transcript ? "View Transcript" : "Generate Transcript"}
              </Link>
            </Button>
            {video.status === "draft" && (
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
                Publish
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  )
}
