"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ChevronLeft, Send } from "lucide-react"
import DashboardLayout from "@/components/dashboard-layout"

export default function CourseChatPage({ params }) {
  const courseId = params.id
  const [message, setMessage] = useState("")

  // Mock course data
  const [course] = useState({
    id: courseId,
    title: "Introduction to Computer Science",
  })

  // Mock chat data
  const [chat] = useState([
    {
      id: 1,
      sender: {
        name: "Student 1",
        avatar: null,
        initials: "S1",
        role: "student",
      },
      message:
        "Hi Professor, I'm having trouble understanding the concept of recursion. Could you explain it in a different way?",
      timestamp: "10:30 AM",
    },
    {
      id: 2,
      sender: {
        name: "Professor Chad",
        avatar: "/placeholder-user.jpg",
        initials: "PC",
        role: "tutor",
      },
      message:
        "Of course! Think of recursion like a Russian nesting doll. Each doll contains a smaller version of itself, until you reach the smallest doll (the base case). In programming, a recursive function calls itself with a simpler version of the problem until it reaches a base case that can be solved directly.",
      timestamp: "10:35 AM",
    },
    {
      id: 3,
      sender: {
        name: "Student 2",
        avatar: null,
        initials: "S2",
        role: "student",
      },
      message: "That makes sense! So it's like breaking down a big problem into smaller versions of the same problem?",
      timestamp: "10:40 AM",
    },
    {
      id: 4,
      sender: {
        name: "Professor Chad",
        avatar: "/placeholder-user.jpg",
        initials: "PC",
        role: "tutor",
      },
      message:
        "Exactly! A classic example is calculating factorial. To find 5!, we can calculate 5 * 4!, and to find 4!, we calculate 4 * 3!, and so on until we reach 1! which is just 1 (our base case).",
      timestamp: "10:42 AM",
    },
    {
      id: 5,
      sender: {
        name: "Student 3",
        avatar: null,
        initials: "S3",
        role: "student",
      },
      message: "Could you share a simple code example of recursion?",
      timestamp: "10:45 AM",
    },
    {
      id: 6,
      sender: {
        name: "Professor Chad",
        avatar: "/placeholder-user.jpg",
        initials: "PC",
        role: "tutor",
      },
      message:
        "Here's a simple factorial function in JavaScript:\n\nfunction factorial(n) {\n  // Base case\n  if (n <= 1) return 1;\n  \n  // Recursive case\n  return n * factorial(n - 1);\n}\n\nSo factorial(5) would calculate 5 * factorial(4), which calculates 4 * factorial(3), and so on.",
      timestamp: "10:50 AM",
    },
  ])

  const handleSendMessage = () => {
    if (message.trim()) {
      // In a real app, you would send the message to the server
      console.log("Sending message:", message)
      setMessage("")
    }
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <Link
          href={`/dashboard/tutor/courses/${courseId}`}
          className="mb-2 inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition-colors hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
        >
          <ChevronLeft size={16} />
          Back to Course
        </Link>
        <h1 className="text-3xl font-bold tracking-tight">{course.title} - Chat Room</h1>
        <p className="text-slate-500 dark:text-slate-400">Interact with your students in real-time</p>
      </div>

      <div className="flex h-[calc(100vh-200px)] flex-col rounded-lg border bg-white dark:bg-slate-950">
        <div className="border-b p-4">
          <h2 className="font-medium">Course Chat</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">28 students online</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-6">
            {chat.map((message) => (
              <div key={message.id} className="flex items-start gap-3">
                <Avatar className="h-10 w-10">
                  {message.sender.avatar ? (
                    <AvatarImage src={message.sender.avatar || "/placeholder.svg"} alt={message.sender.name} />
                  ) : null}
                  <AvatarFallback>{message.sender.initials}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <div className="font-medium">{message.sender.name}</div>
                    {message.sender.role === "tutor" && (
                      <div className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                        Tutor
                      </div>
                    )}
                    <div className="text-xs text-slate-500 dark:text-slate-400">{message.timestamp}</div>
                  </div>
                  <div className="mt-1 whitespace-pre-wrap text-slate-700 dark:text-slate-300">{message.message}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 rounded-md border border-slate-300 px-3 py-2 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSendMessage()
                }
              }}
            />
            <Button
              onClick={handleSendMessage}
              className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500"
            >
              <Send className="h-4 w-4" />
              <span className="ml-2">Send</span>
            </Button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
