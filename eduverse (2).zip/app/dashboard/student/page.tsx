"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Clock, Search } from "lucide-react"
import DashboardLayout from "@/components/dashboard-layout"

export default function StudentDashboard() {
  const [enrolledCourses] = useState([
    {
      id: 1,
      title: "Introduction to Computer Science",
      tutor: "Dr. Sarah Johnson",
      progress: 65,
      lastAccessed: "2 days ago",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      title: "Web Development Fundamentals",
      tutor: "Prof. David Williams",
      progress: 30,
      lastAccessed: "1 week ago",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
  ])

  const [recommendedCourses] = useState([
    {
      id: 3,
      title: "Advanced Data Structures",
      tutor: "Dr. Sarah Johnson",
      students: 64,
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 4,
      title: "Machine Learning Basics",
      tutor: "Prof. Michael Chen",
      students: 128,
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 5,
      title: "Mobile App Development",
      tutor: "Jane Smith",
      students: 96,
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
  ])

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Student Dashboard</h1>
        <Button asChild className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
          <Link href="/courses">
            <Search className="mr-2 h-4 w-4" /> Find Courses
          </Link>
        </Button>
      </div>

      <Tabs defaultValue="enrolled" className="mt-6">
        <TabsList>
          <TabsTrigger value="enrolled">My Courses</TabsTrigger>
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
        </TabsList>
        <TabsContent value="enrolled" className="mt-6">
          <h2 className="mb-4 text-xl font-semibold">Continue Learning</h2>
          <div className="grid gap-6 md:grid-cols-2">
            {enrolledCourses.map((course) => (
              <EnrolledCourseCard key={course.id} course={course} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="recommended" className="mt-6">
          <h2 className="mb-4 text-xl font-semibold">Recommended For You</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {recommendedCourses.map((course) => (
              <RecommendedCourseCard key={course.id} course={course} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="messages">
          <div className="rounded-lg border shadow-sm">
            <div className="p-6">
              <h3 className="text-lg font-medium">Recent Messages</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                View and respond to messages from your tutors and peers.
              </p>
            </div>
            <div className="border-t">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="border-t p-4">
                  <div className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-slate-200 dark:bg-slate-700"></div>
                    <div>
                      <div className="font-medium">{i % 2 === 0 ? "Dr. Sarah Johnson" : "Prof. David Williams"}</div>
                      <div className="text-sm text-slate-500 dark:text-slate-400">
                        {enrolledCourses[i % enrolledCourses.length].title}
                      </div>
                      <div className="mt-1">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut
                        labore.
                      </div>
                      <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                        {new Date().toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-8">
        <h2 className="mb-4 text-xl font-semibold">Recent Activity</h2>
        <Card>
          <CardHeader>
            <CardTitle>Your Learning Activity</CardTitle>
            <CardDescription>Track your progress across all courses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {enrolledCourses.map((course) => (
                <div key={course.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{course.title}</div>
                    <div className="text-sm text-slate-500 dark:text-slate-400">{course.progress}%</div>
                  </div>
                  <Progress value={course.progress} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

function EnrolledCourseCard({ course }) {
  return (
    <Card className="overflow-hidden">
      <div className="relative">
        <img src={course.thumbnail || "/placeholder.svg"} alt={course.title} className="h-40 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <div className="absolute bottom-2 left-2 right-2">
          <div className="flex items-center justify-between">
            <div className="text-sm font-medium text-white">{course.progress}% complete</div>
            <div className="flex items-center text-xs text-white">
              <Clock className="mr-1 h-3 w-3" />
              {course.lastAccessed}
            </div>
          </div>
          <Progress value={course.progress} className="h-1 bg-white/30" />
        </div>
      </div>
      <CardHeader>
        <CardTitle>{course.title}</CardTitle>
        <CardDescription>Tutor: {course.tutor}</CardDescription>
      </CardHeader>
      <div className="flex border-t p-4">
        <Button asChild className="mr-2 bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
          <Link href={`/dashboard/student/courses/${course.id}`}>Continue</Link>
        </Button>
        <Button asChild variant="outline">
          <Link href={`/dashboard/student/courses/${course.id}/chat`}>Chat</Link>
        </Button>
      </div>
    </Card>
  )
}

function RecommendedCourseCard({ course }) {
  return (
    <Card className="overflow-hidden">
      <img src={course.thumbnail || "/placeholder.svg"} alt={course.title} className="h-40 w-full object-cover" />
      <CardHeader>
        <CardTitle>{course.title}</CardTitle>
        <CardDescription>Tutor: {course.tutor}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center text-sm">
          <BookOpen className="mr-1 h-4 w-4 text-slate-500 dark:text-slate-400" />
          <span>{course.students} students enrolled</span>
        </div>
      </CardContent>
      <div className="flex border-t p-4">
        <Button asChild className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
          <Link href={`/courses/${course.id}`}>View Course</Link>
        </Button>
      </div>
    </Card>
  )
}
