"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ChevronLeft, ChevronRight, MessageCircle, Pause, Play, Volume2 } from "lucide-react"
import DashboardLayout from "@/components/dashboard-layout"

export default function StudentCoursePage({ params }) {
  const courseId = params.id
  const [isPlaying, setIsPlaying] = useState(false)
  const [showTranscript, setShowTranscript] = useState(true)

  // Mock course data
  const [course] = useState({
    id: courseId,
    title: "Introduction to Computer Science",
    tutor: {
      name: "Dr. Sarah Johnson",
      avatar: "/placeholder-user.jpg",
    },
    currentVideo: {
      id: 2,
      title: "What is Computer Science?",
      description:
        "This lecture introduces the fundamental concepts of computer science and its importance in today's world.",
    },
    videos: [
      {
        id: 1,
        title: "Introduction to the Course",
        duration: "10:15",
        completed: true,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 2,
        title: "What is Computer Science?",
        duration: "15:30",
        completed: false,
        current: true,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 3,
        title: "Algorithms Basics",
        duration: "20:45",
        completed: false,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 4,
        title: "Data Structures Overview",
        duration: "18:20",
        completed: false,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 5,
        title: "Introduction to Programming",
        duration: "25:10",
        completed: false,
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
    ],
    transcript: [
      { time: "00:00", text: "Welcome to this lecture on 'What is Computer Science?'" },
      { time: "00:05", text: "Computer science is the study of computers and computational systems." },
      {
        time: "00:12",
        text: "Unlike electrical and computer engineers, computer scientists deal mostly with software and software systems.",
      },
      { time: "00:20", text: "These include their theory, design, development, and application." },
      {
        time: "00:26",
        text: "Principal areas of study within computer science include artificial intelligence, computer systems, databases, graphics, networks, programming languages, security, and software engineering.",
      },
      {
        time: "00:40",
        text: "Computer science has many specialized fields, such as computational complexity theory, computer graphics, and programming language theory.",
      },
      {
        time: "00:50",
        text: "Let's dive deeper into what makes computer science such a fascinating and important field in today's world.",
      },
      {
        time: "01:00",
        text: "Computer science is fundamentally about problem-solving. It's about developing systematic approaches to solve problems efficiently.",
      },
      {
        time: "01:10",
        text: "This involves designing algorithms, which are step-by-step procedures for calculations.",
      },
      {
        time: "01:18",
        text: "These algorithms are then implemented using programming languages to create software applications.",
      },
    ],
  })

  return (
    <DashboardLayout>
      <div className="mb-6">
        <Link
          href="/dashboard/student/courses"
          className="mb-2 inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition-colors hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
        >
          <ChevronLeft size={16} />
          Back to My Courses
        </Link>
        <h1 className="text-3xl font-bold tracking-tight">{course.title}</h1>
        <div className="mt-1 flex items-center gap-2">
          <Avatar className="h-6 w-6">
            <AvatarImage src={course.tutor.avatar || "/placeholder.svg"} alt={course.tutor.name} />
            <AvatarFallback>SJ</AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium">{course.tutor.name}</span>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="relative aspect-video overflow-hidden rounded-lg bg-black">
            <img
              src="/placeholder.svg?height=400&width=800"
              alt="Video placeholder"
              className="h-full w-full object-cover opacity-80"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                variant="ghost"
                size="icon"
                className="h-16 w-16 rounded-full bg-white/10 text-white backdrop-blur-sm hover:bg-white/20"
                onClick={() => setIsPlaying(!isPlaying)}
              >
                {isPlaying ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8" />}
              </Button>
            </div>
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <div className="mb-2 flex items-center justify-between text-white">
                <div className="text-sm">00:45 / 15:30</div>
                <div className="flex items-center gap-4">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                    <Volume2 className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                    <MessageCircle className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              <div className="h-1 w-full overflow-hidden rounded-full bg-white/30">
                <div className="h-full w-[5%] rounded-full bg-blue-600"></div>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <h2 className="text-2xl font-bold">{course.currentVideo.title}</h2>
            <p className="mt-2 text-slate-700 dark:text-slate-300">{course.currentVideo.description}</p>

            <div className="mt-6 flex items-center justify-between">
              <Button
                variant="outline"
                className="flex items-center gap-2"
                onClick={() => setShowTranscript(!showTranscript)}
              >
                {showTranscript ? "Hide Transcript" : "Show Transcript"}
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" className="flex items-center gap-2">
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                <Button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {showTranscript && (
              <Card className="mt-4">
                <CardContent className="p-4">
                  <h3 className="mb-4 text-lg font-medium">AI-Generated Transcript</h3>
                  <div className="max-h-80 space-y-4 overflow-y-auto">
                    {course.transcript.map((item, index) => (
                      <div key={index} className="flex gap-3">
                        <div className="w-12 shrink-0 text-sm font-medium text-slate-500 dark:text-slate-400">
                          {item.time}
                        </div>
                        <div className="text-slate-700 dark:text-slate-300">{item.text}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <div>
          <Tabs defaultValue="videos">
            <TabsList className="w-full">
              <TabsTrigger value="videos" className="flex-1">
                Videos
              </TabsTrigger>
              <TabsTrigger value="chat" className="flex-1">
                Chat
              </TabsTrigger>
            </TabsList>
            <TabsContent value="videos" className="mt-4">
              <div className="rounded-lg border">
                <div className="p-4">
                  <h3 className="font-medium">Course Content</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    {course.videos.length} videos •{" "}
                    {course.videos
                      .reduce((acc, video) => {
                        const [min, sec] = video.duration.split(":").map(Number)
                        return acc + min + sec / 60
                      }, 0)
                      .toFixed(1)}{" "}
                    hours total
                  </p>
                </div>
                <div className="max-h-[500px] overflow-y-auto">
                  {course.videos.map((video) => (
                    <div
                      key={video.id}
                      className={`flex items-start gap-3 border-t p-4 ${video.current ? "bg-blue-50 dark:bg-blue-900/20" : ""}`}
                    >
                      <div className="relative h-16 w-28 shrink-0">
                        <img
                          src={video.thumbnail || "/placeholder.svg"}
                          alt={video.title}
                          className="h-full w-full rounded object-cover"
                        />
                        {video.completed && (
                          <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                            <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          </div>
                        )}
                      </div>
                      <div>
                        <div className="font-medium">{video.title}</div>
                        <div className="text-sm text-slate-500 dark:text-slate-400">{video.duration}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
            <TabsContent value="chat" className="mt-4">
              <div className="flex h-[500px] flex-col rounded-lg border">
                <div className="border-b p-4">
                  <h3 className="font-medium">Course Chat</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Chat with your tutor and classmates</p>
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={course.tutor.avatar || "/placeholder.svg"} alt={course.tutor.name} />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                      <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
                        <div className="font-medium">{course.tutor.name}</div>
                        <div className="text-slate-700 dark:text-slate-300">
                          Welcome to the course chat! Feel free to ask any questions about the lecture.
                        </div>
                        <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">10:30 AM</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>S1</AvatarFallback>
                      </Avatar>
                      <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
                        <div className="font-medium">Student 1</div>
                        <div className="text-slate-700 dark:text-slate-300">
                          Could you explain more about the difference between computer science and software engineering?
                        </div>
                        <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">10:35 AM</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={course.tutor.avatar || "/placeholder.svg"} alt={course.tutor.name} />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                      <div className="rounded-lg bg-slate-100 p-3 dark:bg-slate-800">
                        <div className="font-medium">{course.tutor.name}</div>
                        <div className="text-slate-700 dark:text-slate-300">
                          Great question! Computer science focuses more on the theoretical foundations, while software
                          engineering is more about applying those principles to build software systems. We'll cover
                          this in more detail in the next lecture.
                        </div>
                        <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">10:40 AM</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="border-t p-4">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Type your message..."
                      className="flex-1 rounded-md border border-slate-300 px-3 py-2 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
                    />
                    <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
                      Send
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </DashboardLayout>
  )
}
