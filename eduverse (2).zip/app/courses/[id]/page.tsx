"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { BookOpen, ChevronLeft, MessageCircle, Play, Star, Users } from "lucide-react"
import Navbar from "@/components/navbar"

export default function CoursePage({ params }) {
  const courseId = params.id

  // Mock course data
  const [course] = useState({
    id: courseId,
    title: "Introduction to Computer Science",
    description:
      "A comprehensive introduction to the fundamental principles of computer science, covering algorithms, data structures, and programming concepts. This course is designed for beginners with no prior experience in computer science.",
    tutor: {
      name: "Dr. Sarah Johnson",
      title: "Computer Science Professor",
      bio: "Dr. Sarah Johnson has been teaching computer science for over 10 years. She specializes in algorithms and data structures.",
      avatar: "/placeholder-user.jpg",
    },
    rating: 4.8,
    students: 128,
    videos: [
      {
        id: 1,
        title: "Introduction to the Course",
        duration: "10:15",
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 2,
        title: "What is Computer Science?",
        duration: "15:30",
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      { id: 3, title: "Algorithms Basics", duration: "20:45", thumbnail: "/placeholder.svg?height=120&width=200" },
      {
        id: 4,
        title: "Data Structures Overview",
        duration: "18:20",
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
      {
        id: 5,
        title: "Introduction to Programming",
        duration: "25:10",
        thumbnail: "/placeholder.svg?height=120&width=200",
      },
    ],
    price: 49.99,
  })

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navbar />

      <div className="container mx-auto px-4 py-20">
        <Link
          href="/courses"
          className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition-colors hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
        >
          <ChevronLeft size={16} />
          Back to Courses
        </Link>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h1 className="mb-4 text-3xl font-bold text-slate-900 dark:text-white md:text-4xl">{course.title}</h1>

            <div className="mb-6 flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={course.tutor.avatar || "/placeholder.svg"} alt={course.tutor.name} />
                  <AvatarFallback>SJ</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">{course.tutor.name}</span>
              </div>
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm font-medium">{course.rating}</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                <span className="text-sm">{course.students} students</span>
              </div>
            </div>

            <Tabs defaultValue="overview">
              <TabsList className="mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                <TabsTrigger value="instructor">Instructor</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-slate-800">
                  <h2 className="mb-4 text-xl font-semibold">About This Course</h2>
                  <p className="mb-6 text-slate-700 dark:text-slate-300">{course.description}</p>

                  <h3 className="mb-3 text-lg font-semibold">What You'll Learn</h3>
                  <ul className="mb-6 grid gap-2 md:grid-cols-2">
                    <li className="flex items-start gap-2">
                      <div className="mt-1 rounded-full bg-blue-100 p-0.5 dark:bg-blue-900/30">
                        <svg
                          className="h-3 w-3 text-blue-600 dark:text-blue-400"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-slate-700 dark:text-slate-300">Fundamental computer science concepts</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="mt-1 rounded-full bg-blue-100 p-0.5 dark:bg-blue-900/30">
                        <svg
                          className="h-3 w-3 text-blue-600 dark:text-blue-400"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-slate-700 dark:text-slate-300">Basic algorithm design and analysis</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="mt-1 rounded-full bg-blue-100 p-0.5 dark:bg-blue-900/30">
                        <svg
                          className="h-3 w-3 text-blue-600 dark:text-blue-400"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-slate-700 dark:text-slate-300">
                        Common data structures and their applications
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="mt-1 rounded-full bg-blue-100 p-0.5 dark:bg-blue-900/30">
                        <svg
                          className="h-3 w-3 text-blue-600 dark:text-blue-400"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-slate-700 dark:text-slate-300">
                        Programming fundamentals and problem-solving
                      </span>
                    </li>
                  </ul>

                  <h3 className="mb-3 text-lg font-semibold">Requirements</h3>
                  <ul className="mb-6 space-y-2">
                    <li className="flex items-start gap-2">
                      <div className="mt-1 text-blue-600 dark:text-blue-400">•</div>
                      <span className="text-slate-700 dark:text-slate-300">
                        No prior programming experience required
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="mt-1 text-blue-600 dark:text-blue-400">•</div>
                      <span className="text-slate-700 dark:text-slate-300">Basic computer literacy</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="mt-1 text-blue-600 dark:text-blue-400">•</div>
                      <span className="text-slate-700 dark:text-slate-300">High school level mathematics</span>
                    </li>
                  </ul>
                </div>
              </TabsContent>

              <TabsContent value="curriculum">
                <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-slate-800">
                  <h2 className="mb-4 text-xl font-semibold">Course Content</h2>
                  <p className="mb-6 text-slate-500 dark:text-slate-400">
                    {course.videos.length} videos •{" "}
                    {course.videos
                      .reduce((acc, video) => {
                        const [min, sec] = video.duration.split(":").map(Number)
                        return acc + min + sec / 60
                      }, 0)
                      .toFixed(1)}{" "}
                    hours total
                  </p>

                  <div className="space-y-4">
                    {course.videos.map((video) => (
                      <div key={video.id} className="flex flex-col gap-4 rounded-lg border p-4 sm:flex-row">
                        <div className="relative h-24 w-full sm:w-36">
                          <img
                            src={video.thumbnail || "/placeholder.svg"}
                            alt={video.title}
                            className="h-full w-full rounded-md object-cover"
                          />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="rounded-full bg-black/50 p-2">
                              <Play className="h-4 w-4 fill-white text-white" />
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-1 flex-col justify-between">
                          <div>
                            <h3 className="font-medium">{video.title}</h3>
                            <p className="text-sm text-slate-500 dark:text-slate-400">{video.duration}</p>
                          </div>
                          <div className="mt-2 flex items-center gap-2">
                            <Button variant="outline" size="sm" className="text-xs">
                              Preview
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="instructor">
                <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-slate-800">
                  <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={course.tutor.avatar || "/placeholder.svg"} alt={course.tutor.name} />
                      <AvatarFallback>SJ</AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="mb-1 text-xl font-semibold">{course.tutor.name}</h2>
                      <p className="mb-2 text-slate-500 dark:text-slate-400">{course.tutor.title}</p>
                      <div className="mb-4 flex items-center gap-4">
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{course.rating} Instructor Rating</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                          <span className="text-sm">{course.students} Students</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <BookOpen className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                          <span className="text-sm">3 Courses</span>
                        </div>
                      </div>
                      <p className="text-slate-700 dark:text-slate-300">{course.tutor.bio}</p>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="reviews">
                <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-slate-800">
                  <h2 className="mb-4 text-xl font-semibold">Student Reviews</h2>
                  <div className="mb-6 flex items-center gap-4">
                    <div className="text-center">
                      <div className="text-4xl font-bold">{course.rating}</div>
                      <div className="flex items-center justify-center">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${i < Math.floor(course.rating) ? "fill-yellow-400 text-yellow-400" : "text-slate-300 dark:text-slate-600"}`}
                          />
                        ))}
                      </div>
                      <div className="text-sm text-slate-500 dark:text-slate-400">Course Rating</div>
                    </div>
                    <div className="flex-1">
                      {[5, 4, 3, 2, 1].map((rating) => (
                        <div key={rating} className="mb-1 flex items-center gap-2">
                          <div className="text-sm">{rating} stars</div>
                          <div className="h-2 flex-1 rounded-full bg-slate-200 dark:bg-slate-700">
                            <div
                              className="h-2 rounded-full bg-yellow-400"
                              style={{
                                width: `${rating === 5 ? 70 : rating === 4 ? 20 : rating === 3 ? 7 : rating === 2 ? 2 : 1}%`,
                              }}
                            ></div>
                          </div>
                          <div className="text-sm text-slate-500 dark:text-slate-400">
                            {rating === 5 ? 70 : rating === 4 ? 20 : rating === 3 ? 7 : rating === 2 ? 2 : 1}%
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-6">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="border-t pt-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback>{`S${i + 1}`}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">Student {i + 1}</div>
                            <div className="mb-2 flex items-center gap-2">
                              <div className="flex">
                                {Array.from({ length: 5 }).map((_, j) => (
                                  <Star
                                    key={j}
                                    className={`h-4 w-4 ${j < 5 - (i % 2) ? "fill-yellow-400 text-yellow-400" : "text-slate-300 dark:text-slate-600"}`}
                                  />
                                ))}
                              </div>
                              <span className="text-xs text-slate-500 dark:text-slate-400">1 month ago</span>
                            </div>
                            <p className="text-slate-700 dark:text-slate-300">
                              {i === 0
                                ? "This course is excellent! The instructor explains complex concepts in a way that's easy to understand. Highly recommended for beginners."
                                : i === 1
                                  ? "Great introduction to computer science. The videos are well-produced and the content is comprehensive."
                                  : "I've learned so much from this course. The instructor is knowledgeable and engaging."}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <div>
            <Card className="sticky top-20">
              <CardContent className="p-0">
                <img
                  src="/placeholder.svg?height=200&width=400"
                  alt={course.title}
                  className="h-48 w-full object-cover"
                />
                <div className="p-6">
                  <div className="mb-4 text-2xl font-bold">${course.price}</div>
                  <Button className="mb-4 w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500">
                    Enroll Now
                  </Button>
                  <Button variant="outline" className="mb-6 w-full">
                    Add to Wishlist
                  </Button>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-slate-500 dark:text-slate-400" />
                      <span>{course.videos.length} videos</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MessageCircle className="h-5 w-5 text-slate-500 dark:text-slate-400" />
                      <span>Real-time chat support</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-slate-500 dark:text-slate-400" />
                      <span>Join {course.students} students</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
