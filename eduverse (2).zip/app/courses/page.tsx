import Link from "next/link"
import styles from "@/styles/courses.module.css"
import Navbar from "@/components/navbar"

export default function CoursesPage() {
  // Mock course data
  const courses = [
    {
      id: 1,
      title: "Introduction to Computer Science",
      description: "A beginner-friendly course covering the fundamentals of computer science.",
      tutor: "Dr. Sarah Johnson",
      rating: 4.8,
      students: 128,
      price: 49.99,
      thumbnail: "/placeholder.svg?height=200&width=300",
      category: "Computer Science",
      level: "Beginner",
    },
    {
      id: 2,
      title: "Advanced Data Structures",
      description: "Deep dive into complex data structures and algorithms.",
      tutor: "Prof. David Williams",
      rating: 4.7,
      students: 64,
      price: 59.99,
      thumbnail: "/placeholder.svg?height=200&width=300",
      category: "Computer Science",
      level: "Advanced",
    },
    {
      id: 3,
      title: "Web Development Fundamentals",
      description: "Learn the basics of HTML, CSS, and JavaScript.",
      tutor: "Jane Smith",
      rating: 4.9,
      students: 256,
      price: 39.99,
      thumbnail: "/placeholder.svg?height=200&width=300",
      category: "Web Development",
      level: "Beginner",
    },
    {
      id: 4,
      title: "Machine Learning Basics",
      description: "Introduction to machine learning concepts and applications.",
      tutor: "Dr. Michael Chen",
      rating: 4.6,
      students: 192,
      price: 69.99,
      thumbnail: "/placeholder.svg?height=200&width=300",
      category: "Data Science",
      level: "Intermediate",
    },
    {
      id: 5,
      title: "Mobile App Development",
      description: "Build cross-platform mobile applications using React Native.",
      tutor: "Alex Rodriguez",
      rating: 4.5,
      students: 96,
      price: 54.99,
      thumbnail: "/placeholder.svg?height=200&width=300",
      category: "Mobile Development",
      level: "Intermediate",
    },
    {
      id: 6,
      title: "Database Design and SQL",
      description: "Learn to design efficient databases and write complex SQL queries.",
      tutor: "Emily Johnson",
      rating: 4.7,
      students: 128,
      price: 49.99,
      thumbnail: "/placeholder.svg?height=200&width=300",
      category: "Database",
      level: "Beginner",
    },
  ]

  // Categories for filtering
  const categories = [
    "All Categories",
    "Computer Science",
    "Web Development",
    "Data Science",
    "Mobile Development",
    "Database",
  ]

  // Levels for filtering
  const levels = ["All Levels", "Beginner", "Intermediate", "Advanced"]

  return (
    <div className={styles.page}>
      <Navbar />

      <div className={styles.hero}>
        <div className={styles.container}>
          <h1 className={styles.heroTitle}>Explore Our Courses</h1>
          <p className={styles.heroText}>
            Discover a wide range of courses taught by expert instructors. Expand your knowledge and skills today.
          </p>
        </div>
      </div>

      <div className={styles.container}>
        <div className={styles.content}>
          <aside className={styles.sidebar}>
            <div className={styles.filterSection}>
              <h3 className={styles.filterTitle}>Categories</h3>
              <ul className={styles.filterList}>
                {categories.map((category) => (
                  <li key={category}>
                    <label className={styles.filterLabel}>
                      <input
                        type="radio"
                        name="category"
                        value={category}
                        defaultChecked={category === "All Categories"}
                      />
                      <span>{category}</span>
                    </label>
                  </li>
                ))}
              </ul>
            </div>

            <div className={styles.filterSection}>
              <h3 className={styles.filterTitle}>Level</h3>
              <ul className={styles.filterList}>
                {levels.map((level) => (
                  <li key={level}>
                    <label className={styles.filterLabel}>
                      <input type="checkbox" name="level" value={level} defaultChecked={level === "All Levels"} />
                      <span>{level}</span>
                    </label>
                  </li>
                ))}
              </ul>
            </div>

            <div className={styles.filterSection}>
              <h3 className={styles.filterTitle}>Price Range</h3>
              <div className={styles.priceRange}>
                <input type="range" min="0" max="100" defaultValue="100" className={styles.priceSlider} />
                <div className={styles.priceLabels}>
                  <span>$0</span>
                  <span>$100</span>
                </div>
              </div>
            </div>

            <button className={styles.filterButton}>Apply Filters</button>
          </aside>

          <main className={styles.main}>
            <div className={styles.courseControls}>
              <div className={styles.courseCount}>{courses.length} courses</div>
              <div className={styles.sortControl}>
                <label htmlFor="sort" className={styles.sortLabel}>
                  Sort by:
                </label>
                <select id="sort" className={styles.sortSelect}>
                  <option value="popular">Most Popular</option>
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Highest Rated</option>
                </select>
              </div>
            </div>

            <div className={styles.courseGrid}>
              {courses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>

            <div className={styles.pagination}>
              <button className={styles.paginationButton} disabled>
                Previous
              </button>
              <div className={styles.paginationNumbers}>
                <button className={`${styles.paginationNumber} ${styles.active}`}>1</button>
                <button className={styles.paginationNumber}>2</button>
                <button className={styles.paginationNumber}>3</button>
                <span className={styles.paginationEllipsis}>...</span>
                <button className={styles.paginationNumber}>10</button>
              </div>
              <button className={styles.paginationButton}>Next</button>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}

function CourseCard({ course }) {
  return (
    <div className={styles.courseCard}>
      <div className={styles.courseImageContainer}>
        <img src={course.thumbnail || "/placeholder.svg"} alt={course.title} className={styles.courseImage} />
        <div className={styles.courseLevel}>{course.level}</div>
      </div>
      <div className={styles.courseContent}>
        <div className={styles.courseCategory}>{course.category}</div>
        <h3 className={styles.courseTitle}>
          <Link href={`/courses/${course.id}`}>{course.title}</Link>
        </h3>
        <p className={styles.courseDescription}>{course.description}</p>
        <div className={styles.courseStats}>
          <div className={styles.courseTutor}>
            <span className={styles.tutorAvatar}>{course.tutor.charAt(0)}</span>
            <span className={styles.tutorName}>{course.tutor}</span>
          </div>
          <div className={styles.courseRating}>
            <StarIcon />
            <span>{course.rating}</span>
          </div>
        </div>
        <div className={styles.courseFooter}>
          <div className={styles.coursePrice}>${course.price}</div>
          <div className={styles.courseStudents}>{course.students} students</div>
        </div>
      </div>
    </div>
  )
}

function StarIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
    </svg>
  )
}
