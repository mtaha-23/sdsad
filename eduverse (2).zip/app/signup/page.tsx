"use client"

import { useState } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, ChevronLeft, User } from "lucide-react"
import Navbar from "@/components/navbar"

export default function SignupPage() {
  const searchParams = useSearchParams()
  const defaultRole = searchParams.get("role") || "student"
  const [activeTab, setActiveTab] = useState(defaultRole)

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navbar />

      <div className="container mx-auto flex min-h-screen flex-col items-center justify-center px-4 py-20">
        <Link
          href="/"
          className="mb-8 flex items-center gap-2 text-sm font-medium text-slate-600 transition-colors hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
        >
          <ChevronLeft size={16} />
          Back to Home
        </Link>

        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold">Create an account</CardTitle>
            <CardDescription>Join EduVerse to start learning or teaching</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="student" className="flex items-center gap-2">
                  <User size={16} />
                  Student
                </TabsTrigger>
                <TabsTrigger value="tutor" className="flex items-center gap-2">
                  <BookOpen size={16} />
                  Tutor
                </TabsTrigger>
              </TabsList>

              <TabsContent value="student">
                <form className="mt-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="student-name">Full Name</Label>
                    <Input id="student-name" placeholder="John Doe" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-email">Email</Label>
                    <Input id="student-email" type="email" placeholder="john@example.com" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-password">Password</Label>
                    <Input id="student-password" type="password" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-confirm-password">Confirm Password</Label>
                    <Input id="student-confirm-password" type="password" required />
                  </div>
                  <div className="space-y-2">
                    <Label>Interests</Label>
                    <RadioGroup defaultValue="all">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="all" id="all" />
                        <Label htmlFor="all">All subjects</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="tech" id="tech" />
                        <Label htmlFor="tech">Technology</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="business" id="business" />
                        <Label htmlFor="business">Business</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="arts" id="arts" />
                        <Label htmlFor="arts">Arts & Humanities</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500"
                  >
                    Create Student Account
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="tutor">
                <form className="mt-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="tutor-name">Full Name</Label>
                    <Input id="tutor-name" placeholder="Dr. Jane Smith" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tutor-email">Email</Label>
                    <Input id="tutor-email" type="email" placeholder="jane@university.edu" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tutor-password">Password</Label>
                    <Input id="tutor-password" type="password" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tutor-confirm-password">Confirm Password</Label>
                    <Input id="tutor-confirm-password" type="password" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tutor-specialty">Specialty</Label>
                    <Input id="tutor-specialty" placeholder="Computer Science, Mathematics, etc." required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tutor-bio">Short Bio</Label>
                    <Input id="tutor-bio" placeholder="Tell us about your teaching experience" required />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500"
                  >
                    Create Tutor Account
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-center text-sm text-slate-600 dark:text-slate-400">
              By creating an account, you agree to our{" "}
              <Link href="/terms" className="text-blue-600 hover:underline dark:text-blue-400">
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="text-blue-600 hover:underline dark:text-blue-400">
                Privacy Policy
              </Link>
            </div>
            <div className="text-center text-sm">
              Already have an account?{" "}
              <Link href="/login" className="text-blue-600 hover:underline dark:text-blue-400">
                Log in
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
