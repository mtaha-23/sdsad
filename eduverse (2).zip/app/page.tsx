"use client"

import { useRef } from "react"
import Link from "next/link"
import { Canvas } from "@react-three/fiber"
import { Environment, Float, PerspectiveCamera, Text3D } from "@react-three/drei"
import { motion, useScroll as useScrollMotion } from "framer-motion"
import Navbar from "@/components/navbar"
import styles from "@/styles/landing.module.css"

export default function LandingPage() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScrollMotion({
    target: containerRef,
    offset: ["start start", "end end"],
  })

  return (
    <div className={styles.container} ref={containerRef}>
      <Navbar />

      {/* Hero Section with 3D */}
      <section className={styles.hero}>
        <div className={styles.canvas}>
          <Canvas>
            <PerspectiveCamera makeDefault position={[0, 0, 10]} fov={50} />
            <ambientLight intensity={0.5} />
            <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
            <Scene scrollProgress={scrollYProgress} />
            <Environment preset="city" />
          </Canvas>
        </div>

        <div className={styles.heroContent}>
          <motion.h1
            className={styles.heroTitle}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Welcome to <span className={styles.highlight}>EduVerse</span>
          </motion.h1>
          <motion.p
            className={styles.heroText}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            The next generation learning platform where knowledge meets innovation. Discover, learn, and connect with
            educators worldwide.
          </motion.p>
          <motion.div
            className={styles.buttonGroup}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Link href="/signup" className={styles.primaryButton}>
              Get Started
            </Link>
            <Link href="/courses" className={styles.secondaryButton}>
              Explore Courses
            </Link>
          </motion.div>
        </div>

        <div className={styles.scrollIndicator}>
          <motion.div
            className={styles.scrollIcon}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 0.5 }}
          >
            <svg className={styles.arrowDown} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className={styles.features}>
        <div className={styles.container}>
          <h2 className={styles.sectionTitle}>Why Choose EduVerse?</h2>
          <div className={styles.featureGrid}>
            <FeatureCard
              icon={<VideoIcon />}
              title="AI-Enhanced Videos"
              description="Our platform automatically generates transcripts for all uploaded videos, making content more accessible."
            />
            <FeatureCard
              icon={<MessageIcon />}
              title="Real-Time Interaction"
              description="Connect with tutors and peers through our real-time chat rooms for each course."
            />
            <FeatureCard
              icon={<BookIcon />}
              title="Comprehensive Courses"
              description="Access a wide range of courses created by expert educators from around the world."
            />
            <FeatureCard
              icon={<GraduationIcon />}
              title="Learn Anywhere"
              description="Study at your own pace, on any device, with our responsive and user-friendly platform."
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className={styles.howItWorks}>
        <div className={styles.container}>
          <h2 className={styles.sectionTitle}>How It Works</h2>
          <div className={styles.howItWorksGrid}>
            <div className={styles.howItWorksCard}>
              <h3 className={styles.cardTitle}>For Students</h3>
              <ul className={styles.stepsList}>
                <WorksItem number="1" text="Sign up for an account" />
                <WorksItem number="2" text="Browse and enroll in courses" />
                <WorksItem number="3" text="Watch videos with AI-generated transcripts" />
                <WorksItem number="4" text="Interact with tutors and peers in real-time" />
              </ul>
              <div className={styles.cardAction}>
                <Link href="/signup?role=student" className={styles.primaryButton}>
                  Join as Student
                </Link>
              </div>
            </div>
            <div className={styles.howItWorksCard}>
              <h3 className={styles.cardTitle}>For Tutors</h3>
              <ul className={styles.stepsList}>
                <WorksItem number="1" text="Create your tutor profile" />
                <WorksItem number="2" text="Design and publish courses" />
                <WorksItem number="3" text="Upload videos with automatic transcription" />
                <WorksItem number="4" text="Engage with students through chat" />
              </ul>
              <div className={styles.cardAction}>
                <Link href="/signup?role=tutor" className={styles.primaryButton}>
                  Join as Tutor
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className={styles.testimonials}>
        <div className={styles.container}>
          <h2 className={styles.sectionTitle}>What Our Users Say</h2>
          <div className={styles.testimonialGrid}>
            <TestimonialCard
              quote="EduVerse has transformed how I teach my computer science courses. The AI transcription feature saves me hours of work!"
              author="Dr. Sarah Johnson"
              role="Computer Science Professor"
            />
            <TestimonialCard
              quote="As a student with dyslexia, having automatic transcripts has made online learning accessible for me for the first time."
              author="Michael Chen"
              role="Engineering Student"
            />
            <TestimonialCard
              quote="The real-time chat feature allows me to connect with my students even outside of class hours. It's been a game-changer."
              author="Prof. David Williams"
              role="Mathematics Instructor"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className={styles.cta}>
        <div className={styles.container}>
          <h2 className={styles.ctaTitle}>Ready to Transform Education?</h2>
          <p className={styles.ctaText}>Join thousands of students and educators on EduVerse today.</p>
          <Link href="/signup" className={styles.ctaButton}>
            Get Started Now
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer}>
        <div className={styles.container}>
          <div className={styles.footerGrid}>
            <div className={styles.footerColumn}>
              <h3 className={styles.footerTitle}>EduVerse</h3>
              <p className={styles.footerText}>Transforming education through technology and innovation.</p>
            </div>
            <div className={styles.footerColumn}>
              <h4 className={styles.footerSubtitle}>Quick Links</h4>
              <ul className={styles.footerLinks}>
                <li>
                  <Link href="/courses" className={styles.footerLink}>
                    Courses
                  </Link>
                </li>
                <li>
                  <Link href="/tutors" className={styles.footerLink}>
                    Tutors
                  </Link>
                </li>
                <li>
                  <Link href="/about" className={styles.footerLink}>
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className={styles.footerLink}>
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div className={styles.footerColumn}>
              <h4 className={styles.footerSubtitle}>Legal</h4>
              <ul className={styles.footerLinks}>
                <li>
                  <Link href="/terms" className={styles.footerLink}>
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className={styles.footerLink}>
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
            <div className={styles.footerColumn}>
              <h4 className={styles.footerSubtitle}>Connect With Us</h4>
              <div className={styles.socialLinks}>
                <a href="#" className={styles.socialLink} aria-label="Twitter">
                  <TwitterIcon />
                </a>
                <a href="#" className={styles.socialLink} aria-label="LinkedIn">
                  <LinkedInIcon />
                </a>
                <a href="#" className={styles.socialLink} aria-label="GitHub">
                  <GitHubIcon />
                </a>
              </div>
            </div>
          </div>
          <div className={styles.footerBottom}>
            <p>&copy; {new Date().getFullYear()} EduVerse. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

// 3D Scene Component
function Scene({ scrollProgress }) {
  return (
    <group>
      <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
        <Text3D
          font="/fonts/Inter_Bold.json"
          size={1.5}
          height={0.2}
          curveSegments={12}
          bevelEnabled
          bevelThickness={0.02}
          bevelSize={0.02}
          bevelOffset={0}
          bevelSegments={5}
          position={[-5, 0, 0]}
        >
          Learn
          <meshStandardMaterial color="#3b82f6" />
        </Text3D>
      </Float>

      <Float speed={2.5} rotationIntensity={0.5} floatIntensity={1.5}>
        <Text3D
          font="/fonts/Inter_Bold.json"
          size={1.5}
          height={0.2}
          curveSegments={12}
          bevelEnabled
          bevelThickness={0.02}
          bevelSize={0.02}
          bevelOffset={0}
          bevelSegments={5}
          position={[0, 2, 1]}
        >
          Connect
          <meshStandardMaterial color="#8b5cf6" />
        </Text3D>
      </Float>

      <Float speed={3} rotationIntensity={0.5} floatIntensity={2}>
        <Text3D
          font="/fonts/Inter_Bold.json"
          size={1.5}
          height={0.2}
          curveSegments={12}
          bevelEnabled
          bevelThickness={0.02}
          bevelSize={0.02}
          bevelOffset={0}
          bevelSegments={5}
          position={[2, -2, -1]}
        >
          Grow
          <meshStandardMaterial color="#10b981" />
        </Text3D>
      </Float>
    </group>
  )
}

// Feature Card Component
function FeatureCard({ icon, title, description }) {
  return (
    <motion.div
      className={styles.featureCard}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <div className={styles.featureIcon}>{icon}</div>
      <h3 className={styles.featureTitle}>{title}</h3>
      <p className={styles.featureDescription}>{description}</p>
    </motion.div>
  )
}

// How It Works Item Component
function WorksItem({ number, text }) {
  return (
    <li className={styles.worksItem}>
      <span className={styles.worksNumber}>{number}</span>
      <span className={styles.worksText}>{text}</span>
    </li>
  )
}

// Testimonial Card Component
function TestimonialCard({ quote, author, role }) {
  return (
    <motion.div
      className={styles.testimonialCard}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <div className={styles.quoteIcon}>"</div>
      <p className={styles.quoteText}>{quote}</p>
      <div className={styles.authorInfo}>
        <p className={styles.authorName}>{author}</p>
        <p className={styles.authorRole}>{role}</p>
      </div>
    </motion.div>
  )
}

// Icons
function VideoIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polygon points="23 7 16 12 23 17 23 7"></polygon>
      <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
    </svg>
  )
}

function MessageIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
    </svg>
  )
}

function BookIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
    </svg>
  )
}

function GraduationIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 10v6M2 10l10-5 10 5-10 5z"></path>
      <path d="M6 12v5c3 3 9 3 12 0v-5"></path>
    </svg>
  )
}

function TwitterIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
    </svg>
  )
}

function LinkedInIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
      <rect x="2" y="9" width="4" height="12"></rect>
      <circle cx="4" cy="4" r="2"></circle>
    </svg>
  )
}

function GitHubIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>
    </svg>
  )
}
